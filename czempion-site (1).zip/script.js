/* ===========================================================
   Czempion English - wspólny skrypt
   =========================================================== */

/* --- KONFIGURACJA: tu w przyszłości podłączysz backend / Klaviyo ---
   Backend Flask (Python App na seohost, konto Justyny) wystawiony pod osobną subdomeną. */
const API_BASE = "https://api.czempionenglish.pl";
/* Po założeniu konta Klaviyo wstaw publiczny identyfikator firmy: */
// const KLAVIYO_COMPANY_ID = "XXXXXX";

/* ===========================================================
   i18n: przelacznik PL / EN (tlumaczenia naturalne, nie doslowne)
   =========================================================== */
let LANG = (function () { try { return localStorage.getItem("cze_lang") === "en" ? "en" : "pl"; } catch (e) { return "pl"; } })();
function pick(pl, en) { return LANG === "en" ? en : pl; }

const I18N_EN = {
  "nav.stakes": "Challenges", "nav.method": "Method", "nav.reviews": "Reviews", "nav.podcast": "Podcast",
  "nav.start": "Get started", "nav.kb": "Resources", "nav.shop": "Shop", "nav.contact": "Contact",
  "nav.cta": "Book a free consultation",

  "hero.pill": "In 3 to 4 months",
  "hero.h1": "<span class='nb'>Speak English.</span><br><span class='nb'>With real confidence.</span>",
  "hero.oneliner": "We help teenagers and adults who have battled English for years move up at least one full level<a href='#disclaimer' class='claim-star'>*</a>.<br><span class='nb'>At work. While travelling. In life.</span>",
  "hero.sub": "No cramming. No embarrassment. Just the logic of the language.",
  "hero.cta": "Book a free consultation",
  "hero.ctaGhost": "See how it works \u2193",
  "hero.hook": "Not ready yet? <a href='#przewodnik'>Download the free PDF guide \u2192</a>",
  "hero.rotEyebrow": "Discover more",
  "hero.stat1": "months to speaking fluently and correctly<a href='#disclaimer' class='claim-star'>*</a>",
  "hero.stat2": "lessons built 100% around you",
  "hero.stat3": "memorising rules by heart",
  "hero.stat4": "paid cancellations, you never pay for a cancelled lesson<a href='#disclaimer' class='claim-star'>*</a>",

  "stack.1big": "+1 level in 3 to 4 months",
  "stack.1p": "Measurable, concrete progress. With us that is not a promise, it is the standard.",
  "stack.2big": "Logic, not memory",
  "stack.2p": "You understand WHY the language works the way it does. Grammar stops being a riddle and becomes a tool.",
  "stack.3big": "A programme tailored to you",
  "stack.3p": "You are not a number in a group. Your goals, your schedule, your pace.",

  "stakes.h2": "Does this sound familiar?",
  "stakes.h3": "You have been learning for years. Progress has stalled. And you are starting to believe it is your fault. It is not.",
  "stakes.c1": "You memorise grammar tables, but the moment you are in a real conversation it all evaporates.",
  "stakes.c2": "You have a 500-day Duolingo streak, yet you still cannot order a coffee without stress.",
  "stakes.c3": "In an English meeting you stay quiet, not because you have nothing to say, but because you are afraid of how it will sound.",
  "stakes.c4": "You feel the language barrier makes you come across as less competent than you really are.",
  "stakes.c5": "After years of study, still not being able to say what you really think. That should not happen to anyone who has given this language so much of their time.",

  "success.h2": "Imagine English simply\u2026 working.",
  "success.h3": "This is what life looks like after three months with the right method.",
  "success.c1": "You sit a job interview in English and walk out with an offer you were once too scared to even apply for.",
  "success.c2": "In a meeting with an international client you speak with ease, no notes, no sweating, no \u201csorry, my English is not so good.\u201d",
  "success.c3": "You watch a show in the original and catch the jokes the subtitles simply miss.",
  "success.c4": "Grammar is your tool, not your prison. You use it intuitively, because you understand how it works.",
  "success.cta": "That is how I want to speak. Book a consultation",

  "guide.h2": "We know what you are going through.",
  "guide.h3": "And we know exactly how to fix it.",
  "guide.empH": "Empathy",
  "guide.empP1": "Traditional school had you cram tables and repeat sentences like a parrot. Then came the apps that turned the same model into a game with points. You have done it for years. Still no results.",
  "guide.empP2": "You are not \u201cbad at languages.\u201d The method is broken. The system you were taught English in was designed for tests, grades and streaks, not for actually saying something to another human being.",
  "guide.compH": "Expertise",
  "guide.comp1": "Hundreds of students, teenagers and adults alike, who raised their level by at least one full step in 3 to 4 months.",
  "guide.comp2": "An original method built on the logic of the language, not on cramming or gamification.",
  "guide.comp3": "An individual plan that evolves with you, because your goals are not a group's goals.",

  "social.h2": "Do not take our word for it.",
  "social.h3": "Listen to the people who have already walked this path.",
  "social.t1": "I studied English for 10 years: school, courses, then apps. I was still afraid to speak. After 3 months with Czempion English I hold conversations at work. Without stress. For the first time I feel I understand the language, not just remember it.",
  "social.t2": "For the first time someone explained to me WHY English grammar works the way it does. I stopped cramming and started understanding. That is the difference between drilling and real learning.",
  "social.t3": "I thought I had a language block. For years I blamed myself. It turned out the problem was the method, not me.",

  "plan.h2": "Your path to fluent English",
  "plan.h3": "Three steps. No catches.",
  "plan.s1h": "Talk to us",
  "plan.s1p": "A free consultation: we map out your level, goals and plan. No commitment, no pushy sales.",
  "plan.s2h": "Start your programme",
  "plan.s2p": "Learning built on the logic of the language, tailored to you. Regular sessions. Real progress from the very first week.",
  "plan.s3h": "Speak with confidence",
  "plan.s3p": "In 3 to 4 months you will feel the difference. So will your colleagues and your career.",
  "plan.cta": "Start with step 1: book a consultation",

  "podcast.h2": "Listen to our podcast",
  "podcast.h3": "Czempion English: nothing by heart, everything by understanding",
  "podcast.embedNote": "The Spotify player uses cookies. Enable them to listen right here.",
  "podcast.embedBtn": "Enable and play",
  "podcast.link": "Listen on Spotify \u2192",

  "expl.h2": "Traditional English learning is broken. Here is why.",
  "expl.p1": "For decades you have been taught the same way: tables, rules, memorising by heart. Then came the apps that turned the same model into a game with points and streaks. The format changed, the substance did not.",
  "expl.p2": "But a language is not a set of formulas. It is a living tool for communicating with another person. At Czempion English we flip the approach. Instead of making you memorise, we show you the logic behind the language. Once you understand WHY something works the way it does, memorising becomes unnecessary.",
  "expl.p3": "That is why our students make in 3 months the progress others wait years for. Not because they are smarter, but because someone finally showed them how the language truly works.",
  "expl.cta": "See what this looks like for you",

  "lead.h2": "Not ready yet? That is OK.",
  "lead.h3": "Start with the free guide and our newsletter.",
  "lead.lead": "Download the guide \u201c5 reasons your English is stuck, and how to change that\u201d and join our newsletter. Useful content only.",
  "lead.cardH": "Get the guide",
  "lead.cardSub": "We will send it to your inbox and share our best tips now and then. Zero spam.",
  "lead.name": "First name",
  "lead.email": "Email",
  "lead.namePh": "John",
  "lead.emailPh": "john@gmail.com",
  "lead.submit": "Sign up and download the guide",
  "lead.successH": "Done!",
  "lead.successNote": "Check your inbox, we have sent you the guide. From now on you will also get our best tips.",
  "lead.note": "Useful content only. Unsubscribe in one click.",

  "foot.ctaH": "Ready to speak with confidence?",
  "foot.ctaP": "Book a free consultation. Together we will map out your level, goals and action plan. No commitment, no pressure.",
  "foot.ctaBtn": "Book a free consultation",
  "foot.ctaOr": "or write to us directly at <a href='mailto:czempionenglish@gmail.com'>czempionenglish@gmail.com</a>",
  "foot.tagline": "Learning English through logic and understanding. +1 level in 3 to 4 months.",
  "foot.contact": "Contact",
  "foot.site": "Site",
  "foot.legal": "Legal",
  "foot.privacy": "Privacy policy",
  "foot.terms": "Terms",
  "foot.disclaimer": "* The results shown (e.g. \u201c3 to 4 months\u201d, \u201cat least one level\u201d) are indicative and depend on your starting level, consistency and engagement. \u201cZero paid cancellations\u201d means you do not pay for lessons cancelled with enough notice; the detailed terms, including the notice period, are set out in the Terms.",
  "foot.copy": "\u00a9 2026 Czempion English. All rights reserved.",

  /* --- strony Sklep i Baza wiedzy (statyczne naglowki) --- */
  "shop.pill": "Shop",
  "shop.h1": "Materials you can buy",
  "shop.sub": "E-books and video courses built on the same method as our lessons. Learn at your own pace, whenever you like.",
  "shop.empty": "Looking for something tailored to you? We arrange individual lessons during a <a href='index.html#kontakt' style='color:var(--accent);font-weight:600'>free consultation</a>.",
  "kb.pill": "Knowledge base",
  "kb.h1": "Learning materials",
  "kb.sub": "Free resources to help you get unstuck: PDFs, video, exercises and recordings. Use them whenever you like.",
  "kb.empty": "New materials are added regularly. Want them first? <a href='index.html#kontakt' style='color:var(--accent);font-weight:600'>Sign up for the guide</a>."
};

const I18N_PL_STORE = new WeakMap();
function applyI18n(scope) {
  const root = scope || document;
  root.querySelectorAll("[data-i18n]").forEach(function (el) {
    if (!I18N_PL_STORE.has(el)) I18N_PL_STORE.set(el, el.innerHTML);
    const k = el.getAttribute("data-i18n");
    el.innerHTML = (LANG === "en" && I18N_EN[k] != null) ? I18N_EN[k] : I18N_PL_STORE.get(el);
  });
  root.querySelectorAll("[data-i18n-ph]").forEach(function (el) {
    if (!el.hasAttribute("data-ph-pl")) el.setAttribute("data-ph-pl", el.getAttribute("placeholder") || "");
    const k = el.getAttribute("data-i18n-ph");
    el.setAttribute("placeholder", (LANG === "en" && I18N_EN[k] != null) ? I18N_EN[k] : el.getAttribute("data-ph-pl"));
  });
}
function applyTitle() {
  const b = document.body; if (!b) return;
  if (!b.hasAttribute("data-title-pl")) b.setAttribute("data-title-pl", document.title);
  const en = b.getAttribute("data-title-en");
  document.title = (LANG === "en" && en) ? en : b.getAttribute("data-title-pl");
}
function updateLangBtn() { const btn = document.getElementById("langToggle"); if (btn) btn.textContent = LANG === "en" ? "PL" : "EN"; }
function setLang(l) { LANG = (l === "en" ? "en" : "pl"); try { localStorage.setItem("cze_lang", LANG); } catch (e) {} document.documentElement.lang = LANG; applyI18n(); applyTitle(); updateLangBtn(); }
function toggleLang() { setLang(LANG === "en" ? "pl" : "en"); }
function initI18n() { document.documentElement.lang = LANG; applyI18n(); applyTitle(); updateLangBtn(); }
if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", initI18n);
else initI18n();


(function () {
  /* Nawigacja: tło po przewinięciu */
  const nav = document.getElementById("nav");
  if (nav) {
    const onScroll = () => nav.classList.toggle("scrolled", window.scrollY > 50);
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
  }

  /* Menu mobilne (burger) */
  const burger = document.getElementById("burger");
  if (burger) {
    burger.addEventListener("click", () => {
      const open = document.body.classList.toggle("nav-menu-open");
      burger.setAttribute("aria-expanded", open);
    });
    document.querySelectorAll(".nav-links a").forEach((a) =>
      a.addEventListener("click", () => document.body.classList.remove("nav-menu-open"))
    );
  }

  /* Pojawianie się elementów przy przewijaniu */
  const reveals = document.querySelectorAll(".reveal");
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    reveals.forEach((el) => el.classList.add("revealed"));
  } else {
    const io = new IntersectionObserver(
      (entries) =>
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("revealed");
            io.unobserve(e.target);
          }
        }),
      { threshold: 0.15, rootMargin: "0px 0px -5% 0px" }
    );
    reveals.forEach((el) => io.observe(el));
  }
})();

/* ===========================================================
   Formularz „Wyślij przewodnik" + newsletter
   Teraz: pokazuje potwierdzenie (wersja poglądowa).
   Docelowo: zapis do Klaviyo (lista newslettera + automatyczny mail z przewodnikiem)
   ALBO POST do backendu Flask, który dalej woła Klaviyo.
   =========================================================== */
function handleLead(form) {
  const payload = {
    name: (form.querySelector('[name="name"]') || {}).value || "",
    email: (form.querySelector('[name="email"]') || {}).value || "",
    source: "lead-magnet",
  };
  const card = form.closest("[data-lead]");
  const btn = form.querySelector('button[type="submit"]');
  if (btn) { btn.disabled = true; btn.dataset.label = btn.textContent; btn.textContent = pick("Zapisuję...","Signing up..."); }
  fetch(`${API_BASE}/api/subscribe`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  })
    .then((r) => (r.ok ? r.json() : Promise.reject(r)))
    .then(() => {
      if (card) {
        card.querySelector(".lead-form-wrap").style.display = "none";
        card.querySelector(".lead-success").style.display = "block";
      }
    })
    .catch(() => {
      if (btn) { btn.disabled = false; btn.textContent = btn.dataset.label || pick("Zapisz się i pobierz przewodnik","Sign up and download the guide"); }
      alert(pick("Nie udało się zapisać. Sprawdź połączenie i spróbuj ponownie.","We could not sign you up. Check your connection and try again."));
    });
  return false;
}

/* ===========================================================
   Sklep - przyciski „Kup"
   Teraz: informacja, że płatności są w przygotowaniu.
   Docelowo: backend tworzy transakcję w Przelewy24 i zwraca link do płatności.
   =========================================================== */
function escHtml(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }

/* Sklep - ekran zamówienia (checkout).
   Teraz: pokazuje cały przepływ płatności (wersja demonstracyjna).
   Docelowo: backend rejestruje transakcję w Przelewy24 i przekierowuje na bramkę. */
function buyProduct(btn) {
  const card = btn.closest(".product-card");
  const q = (s) => (card && card.querySelector(s) ? card.querySelector(s) : null);
  const name = q("h3") ? q("h3").textContent : "Produkt";
  const price = q(".product-price") ? q(".product-price").textContent : "";
  const desc = q(".product-body p") ? q(".product-body p").textContent : "";
  const imgEl = q(".product-media img");
  const img = imgEl ? imgEl.getAttribute("src") : "";
  coProductId = card ? card.getAttribute("data-id") : "";
  openCheckout(name, price, desc, img);
}
let coProductId = "";
let coBaseNum = NaN;
let coBaseStr = "";
function plnFormat(n) { return n.toFixed(2).replace(".", ",") + " zł"; }
function openCheckout(name, price, desc, img) {
  closeCheckout();
  coBaseStr = price || "";
  coBaseNum = parseFloat((price || "").replace(/\s/g, "").replace(/[^\d.,]/g, "").replace(",", "."));
  const media = img
    ? `<div class="checkout-media"><img src="${escHtml(img)}" alt="${escHtml(name)}"></div>`
    : `<div class="checkout-media checkout-media-ph"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M6 3h9l4 4v14a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Z"/><path d="M14 3v5h5"/></svg></div>`;
  const ov = document.createElement("div");
  ov.className = "checkout-overlay";
  ov.id = "checkoutOverlay";
  ov.innerHTML = `
    <div class="checkout-card" role="dialog" aria-modal="true" aria-label="Zamówienie">
      <button class="checkout-close" aria-label="Zamknij" onclick="closeCheckout()">&times;</button>
      <div class="checkout-eyebrow">${pick("Zamówienie","Order")}</div>
      <div class="checkout-product">
        ${media}
        <div class="checkout-pinfo">
          <h3 class="checkout-name">${escHtml(name)}</h3>
          <p class="checkout-desc">${escHtml(desc)}</p>
        </div>
      </div>
      <ul class="checkout-benefits">
        <li>${pick("Dostęp od razu po opłaceniu","Instant access after payment")}</li>
        <li>${pick("Plik do pobrania, dożywotni dostęp","Downloadable file, lifetime access")}</li>
        <li>${pick("Bez abonamentu, płacisz tylko raz","No subscription, you pay once")}</li>
      </ul>
      <label class="checkout-news"><input type="checkbox" id="coNews" onchange="updateCheckout()"> ${pick("Zapisz mnie do newslettera i odbierz <strong>5% zniżki</strong>","Sign me up for the newsletter and get <strong>5% off</strong>")}</label>
      <div class="checkout-fields">
        <input id="coName" class="checkout-input" type="text" placeholder="${pick("Imię i nazwisko","Full name")}" autocomplete="name">
        <input id="coEmail" class="checkout-input" type="email" placeholder="${pick("E-mail (tu wyślemy materiał)","Email (we will send the material here)")}" autocomplete="email">
      </div>
      <div class="checkout-total"><span>${pick("Do zapłaty","Total")}</span><span class="checkout-amount" id="coAmount">${escHtml(coBaseStr)}</span></div>
      <label class="checkout-terms"><input type="checkbox" id="coTerms"> ${pick("Akceptuję <a href='regulamin.html' target='_blank'>regulamin</a> i <a href='polityka-prywatnosci.html' target='_blank'>politykę prywatności</a>","I accept the <a href='regulamin.html' target='_blank'>terms</a> and the <a href='polityka-prywatnosci.html' target='_blank'>privacy policy</a>")}</label>
      <button class="cta-primary full checkout-pay" onclick="payP24()">${pick("Zapłać przez Przelewy24","Pay with Przelewy24")}</button>
      <div class="checkout-trust"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 018 0v3"/></svg> ${pick("Bezpieczna płatność: BLIK, karta, szybki przelew","Secure payment: BLIK, card, instant transfer")}</div>
      <div class="checkout-note" id="checkoutNote"></div>
    </div>`;
  document.body.appendChild(ov);
  document.body.classList.add("modal-open");
  ov.addEventListener("click", (e) => { if (e.target === ov) closeCheckout(); });
  document.addEventListener("keydown", escClose);
  const nm = document.getElementById("coName"); if (nm) nm.focus();
}
function updateCheckout() {
  const news = document.getElementById("coNews");
  const amount = document.getElementById("coAmount");
  if (!amount) return;
  if (news && news.checked && !isNaN(coBaseNum)) {
    amount.innerHTML = `<s>${escHtml(coBaseStr)}</s> ${plnFormat(coBaseNum * 0.95)} <span class="checkout-save">${pick("5% taniej","5% off")}</span>`;
  } else {
    amount.textContent = coBaseStr;
  }
}
function escClose(e) { if (e.key === "Escape") closeCheckout(); }
function closeCheckout() {
  const ov = document.getElementById("checkoutOverlay");
  if (ov) ov.remove();
  document.body.classList.remove("modal-open");
  document.removeEventListener("keydown", escClose);
}
function payP24() {
  const nameEl = document.getElementById("coName");
  const emailEl = document.getElementById("coEmail");
  const news = document.getElementById("coNews");
  const note = document.getElementById("checkoutNote");
  const name = ((nameEl && nameEl.value) || "").trim();
  const email = ((emailEl && emailEl.value) || "").trim();
  const showNote = (msg) => { if (note) { note.classList.add("show"); note.textContent = msg; } };

  if (!name || email.indexOf("@") < 1 || email.indexOf(".") < 0) {
    showNote(pick("Podaj imię i poprawny adres e-mail.","Enter your name and a valid email address."));
    return;
  }

  const terms = document.getElementById("coTerms");
  if (!terms || !terms.checked) {
    showNote(pick("Zaznacz akceptację regulaminu i polityki prywatności.","Please accept the terms and the privacy policy."));
    return;
  }
  if (!coProductId) {
    showNote(pick("Odśwież stronę i spróbuj ponownie (brak danych produktu).","Refresh the page and try again (missing product data)."));
    return;
  }
  const btn = document.querySelector(".checkout-pay");
  if (btn) { btn.disabled = true; btn.textContent = pick("Przekierowuję do płatności...","Redirecting to payment..."); }

  fetch(`${API_BASE}/api/checkout`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ productId: coProductId, name: name, email: email, newsletter: !!(news && news.checked) }),
  })
    .then((r) => r.json().then((j) => (r.ok ? j : Promise.reject(j))))
    .then((d) => {
      if (d && d.redirectUrl) { window.location = d.redirectUrl; }
      else { return Promise.reject({}); }
    })
    .catch((e) => {
      if (btn) { btn.disabled = false; btn.textContent = pick("Zapłać przez Przelewy24","Pay with Przelewy24"); }
      showNote((e && e.error) ? e.error : pick("Nie udało się rozpocząć płatności. Spróbuj ponownie.","We could not start the payment. Please try again."));
    });
}

/* ===========================================================
   Treści Baza wiedzy / Sklep
   Startowo wgrywane są poniższe pozycje (te same, które były na stronie).
   Właścicielka zarządza nimi w panelu (admin.html), a tu pojawiają się na żywo.
   To rozwiązanie tymczasowe (localStorage). Docelowo dane przyjdą z backendu Flask.
   =========================================================== */
(function () {
  const KB_KEY = "cze_kb";
  const SHOP_KEY = "cze_shop";
  const SEED_FLAG = "cze_seeded";
  const SEED_VERSION = "2";

  const PDF_DEMO = "data:application/pdf;base64,JVBERi0xLjQKMSAwIG9iago8PCAvVHlwZSAvQ2F0YWxvZyAvUGFnZXMgMiAwIFIgPj4KZW5kb2JqCjIgMCBvYmoKPDwgL1R5cGUgL1BhZ2VzIC9LaWRzIFszIDAgUl0gL0NvdW50IDEgPj4KZW5kb2JqCjMgMCBvYmoKPDwgL1R5cGUgL1BhZ2UgL1BhcmVudCAyIDAgUiAvTWVkaWFCb3ggWzAgMCA1OTUgODQyXSAvUmVzb3VyY2VzIDw8IC9Gb250IDw8IC9GMSA0IDAgUiA+PiA+PiAvQ29udGVudHMgNSAwIFIgPj4KZW5kb2JqCjQgMCBvYmoKPDwgL1R5cGUgL0ZvbnQgL1N1YnR5cGUgL1R5cGUxIC9CYXNlRm9udCAvSGVsdmV0aWNhID4+CmVuZG9iago1IDAgb2JqCjw8IC9MZW5ndGggMTcyID4+CnN0cmVhbQpCVCAvRjEgMjIgVGYgNzAgNzYwIFRkIChDemVtcGlvbiBFbmdsaXNoKSBUaiAwIC0zMCBUZCAvRjEgMTMgVGYgKE1hdGVyaWFsIHByenlrbGFkb3d5IC0gd2Vyc2phIGRlbW9uc3RyYWN5am5hKSBUaiAwIC0yMiBUZCAoVHUgem5hamR6aWUgc2llIHdsYXNjaXdhIHRyZXNjIG1hdGVyaWFsdS4pIFRqIEVUCmVuZHN0cmVhbQplbmRvYmoKeHJlZgowIDYKMDAwMDAwMDAwMCA2NTUzNSBmIAowMDAwMDAwMDA5IDAwMDAwIG4gCjAwMDAwMDAwNTggMDAwMDAgbiAKMDAwMDAwMDExNSAwMDAwMCBuIAowMDAwMDAwMjQxIDAwMDAwIG4gCjAwMDAwMDAzMTEgMDAwMDAgbiAKdHJhaWxlcgo8PCAvU2l6ZSA2IC9Sb290IDEgMCBSID4+CnN0YXJ0eHJlZgo1MzQKJSVFT0Y=";
  const VIDEO_DEMO = "https://www.youtube.com/results?search_query=angielski+czasy+bez+wkuwania";
  const AUDIO_DEMO = "https://open.spotify.com/episode/2Nm1fC2tRG270K0Gdw5Csy";
  const KB_DEFAULTS = [
    { tag: "PDF", title: "5 powodów, dlaczego Twój angielski stoi w miejscu", desc: "Krótki przewodnik, który pokazuje, co naprawdę blokuje Twoje postępy i jak to odblokować.", file: PDF_DEMO, fileName: "5-powodow.pdf", link: "" },
    { tag: "Wideo", title: "Czasy w angielskim bez wkuwania", desc: "Mini-lekcja, w której tłumaczymy logikę czasów. Raz zrozumiesz, na zawsze zapamiętasz.", file: "", fileName: "", link: VIDEO_DEMO },
    { tag: "Ćwiczenia", title: "50 zdań na spotkanie po angielsku", desc: "Zestaw gotowych zwrotów do wydrukowania. Idealny przed ważnym callem albo prezentacją.", file: PDF_DEMO, fileName: "50-zdan.pdf", link: "" },
    { tag: "Audio", title: "Wymowa: dźwięki, których nie ma w polskim", desc: "Nagranie z ćwiczeniami wymowy. Posłuchaj i powtarzaj, aż zabrzmi naturalnie.", file: "", fileName: "", link: AUDIO_DEMO },
    { tag: "PDF", title: "Phrasal verbs, których używasz w pracy", desc: "Lista najważniejszych czasowników frazowych z przykładami z prawdziwego życia, nie z podręcznika.", file: PDF_DEMO, fileName: "phrasal-verbs.pdf", link: "" },
    { tag: "Wideo", title: "Jak myśleć po angielsku, zamiast tłumaczyć", desc: "Pokazujemy konkretny nawyk, który sprawia, że przestajesz układać zdania w głowie po polsku.", file: "", fileName: "", link: VIDEO_DEMO }
  ];
  const SHOP_DEFAULTS = [
    { tag: "E-book", title: "Gramatyka, która ma sens", desc: "Cały system angielskiej gramatyki wytłumaczony przez logikę, a nie przez suche tabelki. 80 stron konkretów, przykłady z życia i ćwiczenia, które naprawdę zostają w głowie.", price: "49 zł", img: "" },
    { tag: "Kurs wideo", title: "Mów płynnie: 10 lekcji wideo", desc: "Dziesięć nagrań wideo, które krok po kroku przeprowadzą Cię od blokady do swobodnej rozmowy. Oglądasz we własnym tempie i wracasz, kiedy tylko chcesz.", price: "199 zł", img: "" },
    { tag: "Pakiet", title: "E-book + kurs wideo", desc: "E-book i kurs wideo w jednym pakiecie, taniej niż osobno. Najlepszy start, jeśli chcesz ogarnąć angielski kompleksowo i z gotowym planem.", price: "219 zł", img: "" }
  ];

  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  /* jednorazowe wgranie startowych treści (potem zarządzane w panelu) */
  try {
    if (localStorage.getItem(SEED_FLAG) !== SEED_VERSION) {
      localStorage.setItem(KB_KEY, JSON.stringify(KB_DEFAULTS));
      localStorage.setItem(SHOP_KEY, JSON.stringify(SHOP_DEFAULTS));
      localStorage.setItem(SEED_FLAG, SEED_VERSION);
    }
  } catch (e) {}

  const read = (k, def) => { try { const r = localStorage.getItem(k); return r === null ? def : JSON.parse(r); } catch (e) { return def; } };

  const kbGrid = document.getElementById("kb-grid");
  if (kbGrid) {
    const linkKind = (u) => {
      u = (u || "").toLowerCase();
      if (/youtube\.com|youtu\.be|vimeo\.com|wistia/.test(u)) return "video";
      if (/spotify\.com|soundcloud\.com|music\.apple|anchor\.fm|podbean/.test(u)) return "audio";
      return "open";
    };
    const ICON = {
      download: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3v12m0 0l-4-4m4 4l4-4M5 21h14"/></svg>',
      video: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M10 8.5l6 3.5-6 3.5z" fill="currentColor" stroke="none"/></svg>',
      audio: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 14v-1a8 8 0 0116 0v1"/><rect x="3.5" y="14" width="4" height="6" rx="1.6"/><rect x="16.5" y="14" width="4" height="6" rx="1.6"/></svg>',
      open: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 5h5v5M19 5l-8 8M11 5H7a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4"/></svg>'
    };
    const action = (it) => {
      if (it.file) {
        const label = it.tag === "PDF" ? pick("Pobierz PDF","Download PDF") : pick("Pobierz plik","Download file");
        return `<a class="kb-link" href="${esc(it.file)}" download="${esc(it.fileName || "material")}">${ICON.download} ${label}</a>`;
      }
      if (it.link) {
        const k = linkKind(it.link);
        const label = k === "video" ? "Obejrzyj wideo" : k === "audio" ? "Posłuchaj" : "Otwórz materiał";
        return `<a class="kb-link" href="${esc(it.link)}" target="_blank" rel="noopener">${ICON[k]} ${label}</a>`;
      }
      return `<span class="kb-soon">${pick("Dostępne wkrótce","Coming soon")}</span>`;
    };
    const renderKb = (items) => {
      kbGrid.innerHTML = items.length
        ? items.map((it) =>
            `<article class="kb-card reveal revealed"><span class="kb-tag">${esc(it.tag || "Materiał")}</span><h3>${esc(it.title)}</h3><p>${esc(it.desc || "")}</p>${action(it)}</article>`
          ).join("")
        : `<p class="kb-empty" style="grid-column:1/-1">Brak materiałów. Wkrótce dodamy nowe.</p>`;
    };
    const kbFromApi = (it) => ({ tag: it.tag, title: it.title, desc: it.desc, link: it.link || "", file: it.fileUrl ? API_BASE + it.fileUrl : "", fileName: it.fileName || "" });
    renderKb(read(KB_KEY, KB_DEFAULTS)); // natychmiast: dane lokalne (fallback)
    fetch(`${API_BASE}/api/kb`)
      .then((r) => (r.ok ? r.json() : Promise.reject()))
      .then((data) => { if (Array.isArray(data)) renderKb(data.map(kbFromApi)); }) // nadpisz danymi z API
      .catch(() => {}); // brak API -> zostają dane lokalne
  }

  const shopGrid = document.getElementById("shop-grid");
  if (shopGrid) {
    const renderShop = (items) => {
      shopGrid.innerHTML = items.length
        ? items.map((it) => {
            const media = it.img
              ? `<div class="product-media" style="background:#0c1220"><img src="${esc(it.img)}" alt="${esc(it.title)}" style="width:100%;height:100%;object-fit:cover"></div>`
              : `<div class="product-media"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 5a2 2 0 012-2h11a1 1 0 011 1v15a1 1 0 01-1 1H6a2 2 0 01-2-2V5z"/><path d="M4 19a2 2 0 012-2h12"/></svg></div>`;
            return `<article class="product-card reveal revealed" data-id="${it.id || ""}">${media}<div class="product-body"><span class="product-tag">${esc(it.tag || "Produkt")}</span><h3>${esc(it.title)}</h3><p>${esc(it.desc || "")}</p><div class="product-foot"><span class="product-price">${esc(it.price || "")}</span><button class="cta-primary" onclick="buyProduct(this)">Kup</button></div></div></article>`;
          }).join("")
        : `<p class="kb-empty" style="grid-column:1/-1">Brak produktów. Wkrótce dodamy nowe.</p>`;
    };
    const productFromApi = (it) => ({ id: it.id, tag: it.tag, title: it.title, desc: it.desc, price: it.price, img: it.img ? API_BASE + it.img : "" });
    renderShop(read(SHOP_KEY, SHOP_DEFAULTS)); // natychmiast: dane lokalne (fallback)
    fetch(`${API_BASE}/api/products`)
      .then((r) => (r.ok ? r.json() : Promise.reject()))
      .then((data) => { if (Array.isArray(data)) renderShop(data.map(productFromApi)); }) // nadpisz danymi z API
      .catch(() => {}); // brak API -> zostają dane lokalne
  }
})();

/* ===========================================================
   Hero - rotująca karta z hasłami (baza wiedzy / sklep / opinie / podcast)
   Klik przenosi do odpowiedniej sekcji/strony.
   =========================================================== */
(function () {
  const rotator = document.getElementById("heroRotator");
  if (!rotator) return;
  const elMain = document.getElementById("rotMain");
  const elSub = document.getElementById("rotSub");
  const items = [
    { main: "Ucz się za darmo", mainEn: "Learn for free", sub: "baza wiedzy: PDF-y, wideo, audio", subEn: "knowledge base: PDFs, video, audio", href: "baza-wiedzy.html" },
    { main: "Gotowe e-booki i kursy", mainEn: "Ready e-books and courses", sub: "w sklepie, już od 49 zł", subEn: "in the shop, from 49 zł", href: "sklep.html" },
    { main: "Zobacz, kto już mówi", mainEn: "See who is already speaking", sub: "prawdziwe opinie uczniów", subEn: "real student reviews", href: "#social" },
    { main: "Angielski na rozum", mainEn: "English that makes sense", sub: "posłuchaj naszego podcastu", subEn: "listen to our podcast", href: "#podcast" }
  ];
  let i = 0;
  function apply(idx) {
    elMain.textContent = pick(items[idx].main, items[idx].mainEn);
    elSub.textContent = pick(items[idx].sub, items[idx].subEn);
    rotator.setAttribute("href", items[idx].href);
  }
  apply(0);
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  setInterval(() => {
    rotator.classList.add("rot-swap");
    setTimeout(() => {
      i = (i + 1) % items.length;
      apply(i);
      rotator.classList.remove("rot-swap");
    }, 300);
  }, 3200);
})();

/* --- Zgoda na cookies + bramka na osadzony Spotify --- */
const COOKIE_KEY = "cze_cookie_consent";
function enableConsentEmbeds() {
  document.querySelectorAll(".consent-embed[data-src]").forEach((el) => {
    if (!el.getAttribute("src")) el.setAttribute("src", el.getAttribute("data-src"));
  });
  document.querySelectorAll("[data-embed-placeholder]").forEach((el) => { el.style.display = "none"; });
}
function setCookieConsent(value) {
  try { localStorage.setItem(COOKIE_KEY, value); } catch (e) {}
  const bar = document.getElementById("cookieBar");
  if (bar) bar.remove();
  if (value === "all") enableConsentEmbeds();
}
function acceptCookies(all) { setCookieConsent(all ? "all" : "essential"); }
function initCookies() {
  let consent = null;
  try { consent = localStorage.getItem(COOKIE_KEY); } catch (e) {}
  if (consent === "all") { enableConsentEmbeds(); return; }
  if (consent === "essential") return;
  const bar = document.createElement("div");
  bar.id = "cookieBar";
  bar.className = "cookie-bar";
  bar.innerHTML =
    '<p class="cookie-text">' + pick("Używamy plików cookie, aby strona działała poprawnie i aby można było odtworzyć osadzone treści (np. podcast Spotify). Szczegóły w <a href=\"index.html#disclaimer\">informacji na dole strony</a>.", "We use cookies so the site works properly and so embedded content (such as the Spotify podcast) can play. Details in the <a href=\"index.html#disclaimer\">note at the bottom of the page</a>.") + '</p>' +
    '<div class="cookie-actions">' +
    '<button type="button" class="cookie-btn cookie-essential" onclick="acceptCookies(false)">' + pick("Tylko niezbędne","Essential only") + '</button>' +
    '<button type="button" class="cookie-btn cookie-accept" onclick="acceptCookies(true)">' + pick("Akceptuję wszystkie","Accept all") + '</button>' +
    '</div>';
  document.body.appendChild(bar);
}
if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", initCookies);
else initCookies();
